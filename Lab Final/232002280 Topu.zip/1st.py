def fun( ):
    x=int(input("inter a number :"))

    if(x//3 & x//5):
        print("multiple by 3 and 5")
    if(x//10):
        print("number is multidigit")
    elif(x//3 ==0):
        print("multiple by 3")
    elif(x//5 ==0):
        print("multiple by 5")
    else:
        print("nothing multiple")
        print("number is single digit")

fun( )
